# INFINITE DRIVE — Complete browser starter code

This folder contains a browser-playable 3D driving prototype built with HTML, CSS, JavaScript and Three.js.

## Files
- `index.html` — page structure and menus
- `style.css` — responsive UI and mobile controls
- `game.js` — 3D scene, driving loop, vehicle choices, environments, weather and controls

## Run locally
Because `game.js` imports Three.js as an ES module, do not open `index.html` directly with `file://`.
Use a local web server:
- VS Code: install Live Server, right-click `index.html`, choose **Open with Live Server**.
- Or use Python: `python -m http.server 8000`, then open `http://localhost:8000`.

Internet is required to load Three.js from the CDN.

## Publish with GitHub Pages
1. Create a public repository, e.g. `INFINITE-DRIVE`.
2. Upload all three files (`index.html`, `style.css`, `game.js`) to the repository root.
3. Commit the files.
4. Open **Settings → Pages**.
5. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
6. Open the Pages URL shown by GitHub after deployment.

## Controls
- PC: W / Up = accelerate; S / Down / Space = brake; A / Left = steer left; D / Right = steer right.
- Mobile: use the on-screen buttons. Open the GitHub Pages URL in Chrome.

## Honest feature scope
This is a working playable prototype, not a finished commercial game. It includes a simple 3D placeholder car, endless scrolling road scenery, three environment choices, weather/time visual modes, speed display, keyboard and touch controls. It does not yet include online multiplayer, real car suspension/vehicle physics, production-quality car models, a full procedural branching world, licensed radio music, or native Android APK/Windows EXE packaging. Those are separate development steps. GitHub Pages hosts the browser version; native builds require a separate packaging workflow.
