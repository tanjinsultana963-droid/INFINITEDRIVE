import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const root = document.querySelector('#game-root');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8bbbd8);
scene.fog = new THREE.Fog(0x8bbbd8, 45, 210);

const camera = new THREE.PerspectiveCamera(66, innerWidth / innerHeight, 0.1, 450);
camera.position.set(0, 5.3, 10.5);

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = false;
root.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xe4f2ff, 0x4c6047, 1.8);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffffff, 2.1);
sun.position.set(-12, 22, 12);
scene.add(sun);

const material = (color, roughness = 0.9, metalness = 0) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness });

const groundMat = material(0x477746);
const roadMat = material(0x30353b);
const markingMat = material(0xf3e5bc);
const trunkMat = material(0x59412d);
const foliageMat = material(0x285e39);
const railMat = material(0x8b969f, 0.55, 0.35);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), groundMat);
ground.rotation.x = -Math.PI / 2;
ground.position.y = -0.16;
scene.add(ground);

const road = new THREE.Mesh(new THREE.PlaneGeometry(10, 280), roadMat);
road.rotation.x = -Math.PI / 2;
road.position.set(0, 0, -112);
scene.add(road);

for (const x of [-4.85, 4.85]) {
  const edge = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.06, 280), markingMat);
  edge.position.set(x, 0.035, -112);
  scene.add(edge);
}

const laneMarks = [];
for (let z = 15; z > -270; z -= 10) {
  const mark = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.025, 4.2), markingMat);
  mark.position.set(0, 0.025, z);
  scene.add(mark);
  laneMarks.push(mark);
}

const scenery = [];
function createTree(x, z, scale = 1) {
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.2, 2.2, 6), trunkMat);
  trunk.position.y = 1.05;
  group.add(trunk);
  const crown = new THREE.Mesh(new THREE.ConeGeometry(1.1, 2.8, 7), foliageMat);
  crown.position.y = 3;
  group.add(crown);
  group.position.set(x, 0, z);
  group.scale.setScalar(scale);
  scene.add(group);
  scenery.push(group);
}
for (let z = 12; z > -260; z -= 9) {
  createTree(-8 - Math.random() * 6, z, 0.8 + Math.random() * 0.55);
  createTree(8 + Math.random() * 6, z - 4, 0.8 + Math.random() * 0.55);
}

const railings = [];
for (const x of [-5.35, 5.35]) {
  const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.55, 270), railMat);
  rail.position.set(x, 0.55, -112);
  scene.add(rail);
  railings.push(rail);
}

const car = new THREE.Group();
scene.add(car);
const carPaint = material(0x20a5a0, 0.42, 0.15);
const windowMat = material(0x172b3c, 0.25, 0.15);
const rubberMat = material(0x101216);
const lampMat = new THREE.MeshBasicMaterial({ color: 0xfff0c4 });
const body = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.62, 3.6), carPaint);
body.position.y = 0.82;
car.add(body);
const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.48, 0.76, 1.85), windowMat);
cabin.position.set(0, 1.48, -0.12);
car.add(cabin);
const hood = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.18, 0.85), carPaint);
hood.position.set(0, 1.14, -1.32);
car.add(hood);
const wheels = [];
for (const x of [-0.99, 0.99]) {
  for (const z of [-1.18, 1.18]) {
    const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.39, 0.39, 0.25, 18), rubberMat);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(x, 0.4, z);
    car.add(wheel);
    wheels.push(wheel);
  }
}
for (const x of [-0.62, 0.62]) {
  const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.13, 0.05), lampMat);
  lamp.position.set(x, 0.9, -1.83);
  car.add(lamp);
}
car.position.set(0, 0, 3);

const rainDrops = [];
const rainMaterial = new THREE.LineBasicMaterial({ color: 0xb6d9f5, transparent: true, opacity: 0.55 });
const rainGeometry = new THREE.BufferGeometry();
const rainPositions = new Float32Array(240 * 6);
rainGeometry.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
const rainLines = new THREE.LineSegments(rainGeometry, rainMaterial);
rainLines.visible = false;
scene.add(rainLines);

const input = { left: false, right: false, gas: false, brake: false };
let speed = 0;
let steer = 0;
let started = false;
let paused = false;
let activeWorld = 'forest';
let activeWeather = 'day';
let lastTime = performance.now();

const speedEl = document.querySelector('#speed');
const environmentEl = document.querySelector('#environment');
const mainMenu = document.querySelector('#main-menu');
const pauseMenu = document.querySelector('#pause-menu');
const toastEl = document.querySelector('#toast');

function toast(message, duration = 2200) {
  toastEl.textContent = message;
  toastEl.classList.remove('hidden');
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => toastEl.classList.add('hidden'), duration);
}

function setCarStyle(type) {
  body.scale.set(1, 1, 1);
  cabin.scale.set(1, 1, 1);
  if (type === 'cyber') {
    carPaint.color.set(0x9aa5ae);
    body.scale.set(1.12, 1.08, 1.18);
    cabin.scale.set(1.1, 1.12, 1.08);
  } else if (type === 'aqua') {
    carPaint.color.set(0xe0b64d);
    body.scale.set(0.97, 0.96, 0.96);
  } else {
    carPaint.color.set(0x20a5a0);
  }
}

function setWorldStyle(world) {
  activeWorld = world;
  if (world === 'mountain') {
    foliageMat.color.set(0x59634c);
    groundMat.color.set(0x69765b);
  } else if (world === 'bridge') {
    foliageMat.color.set(0x31594e);
    groundMat.color.set(0x586b77);
  } else {
    foliageMat.color.set(0x285e39);
    groundMat.color.set(0x477746);
  }
  railings.forEach(rail => rail.visible = world === 'bridge');
}

function setWeatherStyle(weather) {
  activeWeather = weather;
  rainLines.visible = weather === 'rain';
  if (weather === 'night') {
    scene.background.set(0x071326);
    scene.fog.color.set(0x071326);
    sun.intensity = 0.25;
    hemi.intensity = 0.45;
    environmentEl.textContent = 'SUMMER · NIGHT';
    groundMat.color.set(0x263a31);
  } else if (weather === 'rain') {
    scene.background.set(0x647786);
    scene.fog.color.set(0x647786);
    sun.intensity = 0.8;
    hemi.intensity = 1;
    environmentEl.textContent = 'RAINY WEATHER';
  } else if (weather === 'winter') {
    scene.background.set(0xb9cbd5);
    scene.fog.color.set(0xb9cbd5);
    sun.intensity = 1.25;
    hemi.intensity = 1.35;
    groundMat.color.set(0xcbd5da);
    environmentEl.textContent = 'WINTER';
  } else {
    scene.background.set(0x8bbbd8);
    scene.fog.color.set(0x8bbbd8);
    sun.intensity = 2.1;
    hemi.intensity = 1.8;
    environmentEl.textContent = 'SUMMER · DAY';
    setWorldStyle(activeWorld);
  }
}

function startDrive() {
  setCarStyle(document.querySelector('#vehicle-select').value);
  setWorldStyle(document.querySelector('#world-select').value);
  setWeatherStyle(document.querySelector('#weather-select').value);
  mainMenu.classList.add('hidden');
  pauseMenu.classList.add('hidden');
  started = true;
  paused = false;
  speed = 0;
  toast('Enjoy your drive!');
}
document.querySelector('#start-btn').addEventListener('click', startDrive);
document.querySelector('#controls-btn').addEventListener('click', () => {
  toast('PC: W/↑ Gas · S/↓ Brake · A/← Left · D/→ Right', 4000);
});
document.querySelector('#pause-btn').addEventListener('click', () => {
  if (!started) return;
  paused = true;
  pauseMenu.classList.remove('hidden');
});
document.querySelector('#resume-btn').addEventListener('click', () => {
  paused = false;
  pauseMenu.classList.add('hidden');
});
document.querySelector('#menu-btn').addEventListener('click', () => {
  started = false;
  paused = false;
  speed = 0;
  pauseMenu.classList.add('hidden');
  mainMenu.classList.remove('hidden');
});

function setKey(key, value) {
  if (['arrowleft', 'a'].includes(key)) input.left = value;
  if (['arrowright', 'd'].includes(key)) input.right = value;
  if (['arrowup', 'w'].includes(key)) input.gas = value;
  if (['arrowdown', 's', ' '].includes(key)) input.brake = value;
}
window.addEventListener('keydown', event => {
  const key = event.key.toLowerCase();
  if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(key)) event.preventDefault();
  setKey(key, true);
});
window.addEventListener('keyup', event => setKey(event.key.toLowerCase(), false));
window.addEventListener('blur', () => Object.keys(input).forEach(key => input[key] = false));

document.querySelectorAll('[data-control]').forEach(button => {
  const control = button.dataset.control;
  const down = event => { event.preventDefault(); input[control] = true; };
  const up = event => { event.preventDefault(); input[control] = false; };
  button.addEventListener('pointerdown', down);
  button.addEventListener('pointerup', up);
  button.addEventListener('pointerleave', up);
  button.addEventListener('pointercancel', up);
});

function updateRain(dt) {
  if (!rainLines.visible) return;
  const pos = rainGeometry.attributes.position.array;
  for (let i = 0; i < 240; i++) {
    const j = i * 6;
    let x = pos[j], y = pos[j + 1], z = pos[j + 2];
    if (y === 0 && x === 0 && z === 0) {
      x = (Math.random() - 0.5) * 32;
      y = Math.random() * 18 + 2;
      z = Math.random() * -48 + 8;
    }
    y -= 28 * dt;
    z += 8 * dt;
    if (y < 0) {
      x = (Math.random() - 0.5) * 32;
      y = Math.random() * 18 + 8;
      z = Math.random() * -48 + 8;
    }
    pos[j] = x; pos[j + 1] = y; pos[j + 2] = z;
    pos[j + 3] = x + 0.08; pos[j + 4] = y - 0.65; pos[j + 5] = z + 0.18;
  }
  rainGeometry.attributes.position.needsUpdate = true;
}

function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - lastTime) / 1000, 0.04);
  lastTime = now;

  if (started && !paused) {
    if (input.gas) speed = Math.min(speed + 24 * dt, 150);
    else speed = Math.max(speed - 5.5 * dt, 0);
    if (input.brake) speed = Math.max(speed - 62 * dt, 0);

    const turn = (input.left ? 1 : 0) - (input.right ? 1 : 0);
    steer += (turn - steer) * Math.min(7 * dt, 1);
    car.position.x = THREE.MathUtils.clamp(car.position.x + steer * speed * 0.012 * dt, -3.35, 3.35);
    car.rotation.y = -steer * 0.18;

    const worldMove = speed * dt * 0.24;
    laneMarks.forEach(mark => {
      mark.position.z += worldMove;
      if (mark.position.z > 16) mark.position.z = -270;
    });
    scenery.forEach(tree => {
      tree.position.z += worldMove;
      if (tree.position.z > 18) tree.position.z = -265 - Math.random() * 20;
    });
    wheels.forEach(wheel => wheel.rotation.x -= speed * dt * 0.105);
    speedEl.textContent = Math.round(speed);
  }

  updateRain(dt);
  camera.position.x += (car.position.x * 0.48 - camera.position.x) * 0.06;
  camera.lookAt(car.position.x * 0.3, 1.0, -5);
  renderer.render(scene, camera);
}
requestAnimationFrame(animate);

window.addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
